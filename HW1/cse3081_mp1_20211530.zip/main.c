#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

FILE *fp_in, *fp_out;
char *idx;
int row, col;
int **arr;
int **prefixSum;
int max;

void cal_prefixSum() // O(n^2)
{

     for (int i = 1; i <= row; i++)
     {
          for (int j = 2; j <= col; j++)
          {
               prefixSum[i][j] += prefixSum[i][j - 1];
          }
     }
     for (int i = 2; i <= row; i++)
     {
          for (int j = 1; j <= col; j++)
          {
               prefixSum[i][j] += prefixSum[i - 1][j];
          }
     }
}
void cal_prefixSum_of_col()
{
     for (int i = 2; i <= row; i++)
     {
          for (int j = 1; j <= col; j++)
          {
               prefixSum[i][j] += prefixSum[i - 1][j];
          }
     }
}
void n_six()
{ /*sum of matrix from (i, j) to (x,y)*/
     clock_t start, end;
     start = clock();

     for (int i = 0; i < row; i++)
     {
          for (int j = 0; j < col; j++)
          {
               for (int x = i; x < row; x++)
               {
                    for (int y = j; y < col; y++)
                    {
                         int sum = 0;
                         for (int a = i; a <= x; a++)
                         {
                              for (int b = j; b <= y; b++)
                              {
                                   sum += arr[a][b];
                              }
                         }
                         max = (max < sum) ? sum : max;
                    }
               }
          }
     }
     end = clock();

     fprintf(fp_out, "%d\n", max);
     fprintf(fp_out, "%ld\n", (end - start));
     return;
}
void n_four()
{
     clock_t start, end;
     start = clock();

     cal_prefixSum();
     int sum;
     for (int i = 1; i <= row; i++)
     {
          for (int j = 1; j <= col; j++)
          {
               for (int x = i; x <= row; x++)
               {
                    for (int y = j; y <= col; y++)
                    {
                         sum = prefixSum[x][y] - prefixSum[x][j - 1] - prefixSum[i - 1][y] + prefixSum[i - 1][j - 1];
                         max = (max < sum) ? sum : max;
                    }
               }
          }
     }
     end = clock();

     fprintf(fp_out, "%d\n", max);
     fprintf(fp_out, "%ld\n", (end - start));
     return;
}
void n_three()
{ /*prefix sum in 2D matrix*/
     clock_t start, end;
     start = clock();

     cal_prefixSum_of_col();
     int *tmp = (int *)malloc(sizeof(int) * col);
     for (int i = 1; i <= row; i++) // starting row
     {
          for (int j = i; j <= row; j++) // ending row
          {
               for (int k = 1; k <= col; k++) // travel all col
               {
                    tmp[k - 1] = prefixSum[j][k] - prefixSum[i - 1][k];
               }
               for (int k = 1; k < col; k++) // kadane
               {
                    if (tmp[k - 1] > 0)
                         tmp[k] += tmp[k - 1];
                    max = (tmp[k] > max) ? tmp[k] : max;
               }
          }
     }
     end = clock();
     free(tmp);

     fprintf(fp_out, "%d\n", max);
     fprintf(fp_out, "%ld\n", (end - start));
     return;
}

int main(int argc, char *argv[])
{
     /*get argument and make output fle*/
     fp_in = fopen(argv[1], "r");
     char *str, out[100] = "result_";
     str = argv[1];
     strcat(out, str);
     fp_out = fopen(out, "w");
     idx = argv[2];

     /*reading the input file and set prefixSum array*/
     fscanf(fp_in, "%d %d", &row, &col); // row, col
     arr = (int **)malloc(sizeof(int *) * row);
     prefixSum = (int **)malloc(sizeof(int *) * (row + 1));
     for (int i = 0; i < row; i++)
     {
          arr[i] = (int *)malloc(sizeof(int) * col);
          prefixSum[i] = (int *)malloc(sizeof(int) * (col + 1));
     }
     prefixSum[row] = (int *)malloc(sizeof(int) * (col + 1));

     for (int i = 0; i <= row; i++)
     {
          for (int j = 0; j <= col; j++)
          {
               if (i != row && j != col)
               {
                    fscanf(fp_in, "%d", &arr[i][j]);
                    max = (max > arr[i][j]) ? arr[i][j] : max;
               }
               if (i && j)
                    prefixSum[i][j] = arr[i - 1][j - 1];
          }
     }

     /*print format in output file*/
     fprintf(fp_out, "%s\n%s\n%d\n%d\n", str, idx, row, col);
     /*starting algirhtm*/
     if (!strcmp(idx, "1")) // n^6
     {
          n_six();
     }
     else if (!strcmp(idx, "2")) // n^4
     {
          n_four();
     }
     else if (!strcmp(idx, "3")) // n^3
     {
          n_three();
     }

     /*free arr*/
     for (int i = 0; i < row; i++)
     {
          free(arr[i]);
          free(prefixSum[i]);
     }
     free(prefixSum[row]);
     free(arr);
     free(prefixSum);

     /*close the file*/
     fclose(fp_in);
     fclose(fp_out);
}
